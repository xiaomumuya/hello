var express = require('express');
var router = express.Router();
const staff=require('../sql/staff')

router.get('/',(req,res,next)=>{
    staff.find({},(err,data)=>{
        if(err){
            console.log(err);
        }
        res.render('staff',{
            index:3,
            data:data
        })

    })
})

router.get("/add", function (req, res, next) {
    res.render("staffAdd", {
      index: 3,
    });
  });

router.post('/addAction',(req,res,next)=>{
    var obj=req.body;
    obj.salary=obj.salary-0;
    staff.insertMany(obj,(err,data)=>{
        if(err){
            console.log(err);
        }
        console.log(data);
        res.redirect('/staff')
    })
})

router.get('/delete',(req,res,next)=>{
    var obj=req.query;
    staff.deleteOne({'_id':obj._id},(err,data)=>{
        if(err){
            console.log(err);
        }
        console.log(data);
        res.redirect('/staff')
    })
})

router.get('/update',function(req,res,next){
    console.log(req.query);
    staff.findById({'_id':req.query._id},(err,data)=>{
      if(err){
        console.log(err);
      }
      console.log(data);
      res.render('staffUpdate',{
        index:3,
        data:data
      })
  
    })
  })

  router.post('/updateAction',(req,res,next)=>{
    var obj=req.body;
    obj.salary=obj.salary-0;
    staff.findByIdAndUpdate(obj._id,obj,(err,data)=>{
      if(err){
        console.log(err);
      }
      console.log(data);
      res.redirect('/staff')
  
    })
  })

  router.get('/search',(req,res,next)=>{
    var obj=req.query;
    let reg = new RegExp(obj.search);
    staff.find({staffName:reg},(err,data)=>{
      if(err){
        console.log(err)
      }
      console.log(data);
      res.render("staff", {
      index: 3,
      data:data
      });
    })
  
  })


  router.get("/sort1", (req, res, next) => {
    const obj = req.query;
      staff.find({}).sort({salary:1}).exec((err,data)=>{
       if(err){
         console.log(err)
       }
       console.log(data)
         res.render("staff", {
        index: 3,
        data,
      })
     })
    
  });
  
  router.get("/sort2", (req, res, next) => {
    const obj = req.query;
      staff.find({}).sort({salary:-1}).exec((err,data)=>{
       if(err){
         console.log(err)
       }
       console.log(data)
         res.render("staff", {
        index: 3,
        data,
      })
     })
    // sql.sort(production, {}, {}, obj).then((data) => {
    //   res.render("pro", {
    //     index: 1,
    //     data,
    //   });
    // });
  });
  


module.exports = router;