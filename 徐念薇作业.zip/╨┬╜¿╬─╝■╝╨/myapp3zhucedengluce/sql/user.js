
const db = require('./db.js') 

const adminSchema = new db.mongoose.Schema({
    "userName":{type:String},
    "passWord":{type:String}
    
})


module.exports = db.mongoose.model("users",adminSchema)