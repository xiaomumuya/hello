var express = require('express');
var router = express.Router();
const user = require('../sql/user')
/* GET home page. */
router.get('/', function(req, res, next) {
  user.find({},(err,data)=>{
    if(err){
      console.log(err)
    }
    console.log(data)

    res.render('user', {
      index:2,
      data:data
    });
  })
  
});
router.get('/add',function(req,res,next){
  res.render('userAdd',{
    index:2
  })

})
router.post('/addAction',(req,res,next)=>{
  console.log('我进入addAction了');
  var obj=req.body;
  console.log(obj);
  user.insertMany(obj,(err,data)=>{
    if(err){
      //console.log('错误');
      console.log(err);
    }
    console.log(data);
    res.redirect('/user')

  })
})
router.get('/delete',function(req,res,next){
  console.log(req.query);
  user.deleteOne({'_id':req.query._id},(err,data)=>{
    if(err){
      console.log(err);
    }
    console.log(data);
    res.redirect('/user')
  })

})

router.get('/update',function(req,res,next){
  console.log(req.query);
  user.findById({'_id':req.query._id},(err,data)=>{
    if(err){
      console.log(err);
    }
    console.log(data);
    res.render('userUpdate',{
      index:2,
      data:data
    })

  })

})
router.post('/updateAction',(req,res,next)=>{
  var obj=req.body;
  user.findByIdAndUpdate(obj._id,obj,(err,data)=>{
    if(err){
      console.log(err);
    }
    console.log(data);
    res.redirect('/user')

  })
})

router.get('/search',(req,res,next)=>{
  var obj=req.query;
  let reg = new RegExp(obj.search);
  user.find({userName:reg},(err,data)=>{
    if(err){
      console.log(err)
    }
    console.log(data);
    res.render("user", {
    index: 2,
    data:data
    });
  })

})



module.exports = router;
