const db = require('./db.js');

const staffSchema = new db.mongoose.Schema ({
    "staffName":{type:String},
    "sex":{type:String},
    "age":{type:String},
    "position":{type:String},
    "salary":{type:Number},
    "phoneNumber":{type:String},
})
module.exports=db.mongoose.model('staff',staffSchema)
